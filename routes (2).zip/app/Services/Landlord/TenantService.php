<?php

namespace App\Services\Landlord;

use Exception;
use App\Models\User;
use App\Models\Tenant;
use Illuminate\Support\Str;
use App\Services\Auth\HashService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Artisan;
use App\Contracts\Services\TenantServiceInterface;
use App\Repositories\TenantRepository;
use Illuminate\Database\Eloquent\Collection;

class TenantService implements TenantServiceInterface
{
    public function create(array $tenantData): ?Tenant
    {
        try {
            return DB::connection('landlord')->transaction(function () use ($tenantData) {
                $tenant = Tenant::create([
                    'uuid' => Str::uuid(),
                    'billing_email' => $tenantData['email'],
                    'name' => $tenantData['name'],
                ]);

                if(!$tenant) {
                    throw new Exception("Error creating tenant");
                }

                $this->setUpTenantOwnerData($tenant, $tenantData);

                return $tenant;
            });
        } catch (\Throwable $th) {
            Log::error("Tenant registration error: " . $th->getMessage());
            throw new Exception($th->getMessage());
        }

    }

    public function delete(Tenant $tenant): bool
    {

        return true;
    }

    public function update(Tenant $tenant, array $tenantData): bool
    {
        //
        return true;
    }

    public function statistics(): Collection
    {
        return collect([]);
    }

    public function setUpTenantOwnerData(Tenant $tenant, $tenantOwnerData): void
    {
        $tenant->execute(function () use ($tenantOwnerData) {
            try {
                DB::connection('tenant')->transaction(function () use ($tenantOwnerData) {
                    $emailExists = User::where('email', $tenantOwnerData['email'])->exists();
                    if($emailExists) {
                        throw new Exception("Email already taken");
                    }

                    $this->createOwnerInTenantDatabase($tenantOwnerData);
                    $this->saveDefaultsTenantData();
                });
            } catch (\Throwable $th) {
                Log::error("Error creating tenant owner: " . $th->getMessage());
                throw new Exception($th->getMessage());

            }
        });
    }

    protected function createOwnerInTenantDatabase($tenantData) {

        $tenantOwner = User::create([
            'uuid' => str::uuid(),
            'email' => $tenantData['email'],
            'first_name' => $tenantData['first_name'],
            'last_name' => $tenantData['last_name'],
            'password' =>  app(HashService::class)->make($tenantData['password']),
            'is_owner' => true,
        ]);

        if(!$tenantOwner) {
            throw new Exception("Error creating tenant owner");
        }

        DB::table('user_roles')->insert([
            'user_id' => $tenantOwner->id,
            'role_id' => 1,
            'assigned_by' => null,
            'assigned_at' => now()
        ]);

        return $tenantOwner;
    }

    protected function saveDefaultsTenantData(){
        Artisan::call('db:seed',[
            '--database' => 'tenant',
            '--class' =>  'TenantDatabaseSeeder',
            '--force' => true
        ]);
    }

}
