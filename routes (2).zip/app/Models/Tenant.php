<?php

namespace App\Models;

use Attribute;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Spatie\Multitenancy\Models\Tenant as BaseTenant;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Spatie\Multitenancy\Models\Concerns\UsesLandlordConnection;

class Tenant extends BaseTenant
{
    use HasFactory, UsesLandlordConnection;

    protected $fillable = [
        "name", "uuid", "subdomain", "domain", "slug",
        "database_name", "database_host", "plan_type",
        "subscription_status", "trial_ends_at", "billing_email",
        "status", "max_users", "max_posts", "max_storage_mb"
    ];

    protected $casts = [
        'trial_ends_at' => 'datetime',
    ];

    protected $attributes = [
        'status' => 'active',
    ];
    
    protected static function boot(){
        parent::boot();

        static::creating(function ($tenant) {
            if(empty($tenant->slug)){
                $tenant->slug = static::generateUniqueSlug($tenant->name);
            }

            if(empty($tenant->database_name)){
                $tenant->database_name = static::generateDatabasename($tenant->slug);
            }
        });

        static::created(function ($tenant) {
            $tenant->createDatabase();
            $tenant->runMigrations();
        });

        static::deleting(function ($tenant) {
            $tenant->dropDatabase();
        });

    }

    protected static function generateUniqueSlug(string $name): string
    {
        $actualSlug = Str::slug($name);
        $slug = $actualSlug;
        $counter = 1;

        while (static::where('slug', $slug)->exists()) {
            $slug = $actualSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    protected static function generateDatabasename(string $slug): string {
        $prefix = config('app.env') === 'local' ? 'local_tenant_' : 'tenant_';
        return $prefix . $slug . '_' . Str::random(6);
    }

    public function createDatabase(): void {
        $LandlordDbConnection = config('multitenancy.landlord_database_connection_name');

        DB::connection($LandlordDbConnection)->statement(
            "CREATE DATABASE IF NOT EXISTS `{$this->database_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        );
    }

    public function getDatabaseName(): string
    {
        return $this->database_name;
    }

    public function dropDatabase(): void{
        $LandlordDbConnection = config('multitenancy.landlord_database_connection_name');

        DB::connection($LandlordDbConnection)->statement(
            "DROP DATABASE IF EXISTS `{$this->database_name}`"
        );
    }

    public function runMigrations(): void {
        $this->execute(function () {
            try {
                Artisan::call('migrate', [
                    '--database' => 'tenant',
                    '--path' => 'database/migrations/tenant',
                    '--force' => true
                ]);

                $output = Artisan::output();
                Log::info("Tenant [{$this->id}] migration succeeded. Output: " . $output);
            } catch (\Throwable $th) {
               Log::error("Tenant [{$this->id}] migration failed: " . $th->getMessage());
            }
        });
    }

    public function isActive(): bool {
        return $this->status === 'active';
    }

    public function isOnTrial(): bool {
        return $this->trial_ends_at && $this->trial_ends_at->isFuture();
    }

    public function scopeActive($query){
        return $query->where('status', 'active');
    }

    public function getLocalUrlAttribute(): string {
        return url("/api/{$this->slug}");
    }

    public function getProductionUrlAttribute(): string {
        if($this->domain) {
            $configDomain = config('app.tenant_domain', 'localhost');
            return "https://{$this->domain}.{$configDomain}";
        }

        return $this->local_url;
    }
}
